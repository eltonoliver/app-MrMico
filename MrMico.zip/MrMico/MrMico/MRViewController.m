//
//  MRViewController.m
//  MrMico
//
//  Created by Elton Oliveira on 30/03/14.
//  Copyright (c) 2014 Elton Oliveira. All rights reserved.
//

#import "MRViewController.h"

@interface MRViewController ()

@end

@implementation MRViewController

- (void)viewDidLoad
{
    
    
    //autoload view controller perfil
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
