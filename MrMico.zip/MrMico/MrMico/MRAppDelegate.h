//
//  MRAppDelegate.h
//  MrMico
//
//  Created by Elaine Noronha on 30/03/14.
//  Copyright (c) 2014 Elaine Noronha. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MRAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
